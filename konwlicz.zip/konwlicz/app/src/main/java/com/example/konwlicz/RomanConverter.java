package com.example.konwlicz;

import java.util.HashMap;

public class RomanConverter {

    public static int romanToArabic(String roman) {
        HashMap<Character, Integer> map = new HashMap<>();
        map.put('I', 1);
        map.put('V', 5);
        map.put('X', 10);
        map.put('L', 50);
        map.put('C', 100);
        map.put('D', 500);
        map.put('M', 1000);

        int result = 0;

        for (int i = 0; i < roman.length(); i++) {
            int current = map.get(roman.charAt(i));

            if (i + 1 < roman.length()) {
                int next = map.get(roman.charAt(i + 1));

                if (current < next) {
                    result -= current;
                } else {
                    result += current;
                }
            } else {
                result += current;
            }
        }

        return result;
    }
}