package com.example.konwlicz;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText input;
    TextView result;
    boolean isRomanMode = true;

    LinearLayout layoutRoman, layoutArabic;
    Button btnSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.inputRoman);
        result = findViewById(R.id.textResult);

        layoutRoman = findViewById(R.id.layoutRoman);
        layoutArabic = findViewById(R.id.layoutArabic);
        btnSwitch = findViewById(R.id.btnSwitchMode);

        // Zmiana trybu
        btnSwitch.setOnClickListener(v -> {
            isRomanMode = !isRomanMode;

            input.setText("");
            result.setText("Wynik");

            if (isRomanMode) {
                btnSwitch.setText("Tryb: Rzymskie → Arabskie");

                layoutRoman.setVisibility(View.VISIBLE);
                layoutArabic.setVisibility(View.GONE);

            } else {
                btnSwitch.setText("Tryb: Arabskie → Rzymskie");

                layoutRoman.setVisibility(View.GONE);
                layoutArabic.setVisibility(View.VISIBLE);
            }
        });

        // Rzymskie przyciski
        int[] romanBtns = {R.id.btnI, R.id.btnV, R.id.btnX, R.id.btnL, R.id.btnC, R.id.btnD, R.id.btnM};
        for (int id : romanBtns) {
            Button b = findViewById(id);
            b.setOnClickListener(v -> input.append(b.getText()));
        }

        // Arabskie przyciski
        int[] arabicBtns = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};

        for (int id : arabicBtns) {
            Button b = findViewById(id);
            b.setOnClickListener(v -> input.append(b.getText()));
        }

        // Usuń
        findViewById(R.id.btnDelete).setOnClickListener(v -> {
            String t = input.getText().toString();
            if (!t.isEmpty()) {
                input.setText(t.substring(0, t.length() - 1));
            }
        });

        // Wyczyść
        findViewById(R.id.btnClear).setOnClickListener(v -> {
            input.setText("");
            result.setText("Wynik");
        });

        // Konwersja
        findViewById(R.id.buttonConvert).setOnClickListener(v -> {
            String text = input.getText().toString();

            if (text.isEmpty()) {
                result.setText("Brak danych");
                return;
            }

            if (isRomanMode) {
                int val = RomanConverter.romanToArabic(text);
                result.setText("Wynik: " + val);
            } else {
                int num = Integer.parseInt(text);
                String roman = ArabicToRomanConverter.arabicToRoman(num);
                result.setText("Wynik: " + roman);
            }
        });
    }
}
